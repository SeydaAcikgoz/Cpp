#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QSqlError>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("veritabani.db");
    db.open();
    musteri = new QSqlQuery(db);
    musteriModel = new QSqlQueryModel();
    hesap = new QSqlQuery(db);
    hesapModel = new QSqlQueryModel();
    islem = new QSqlQuery(db);
    musteriListele();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::musteriListele()
{
    musteri->exec("select * from musteriler");
    musteriModel->setQuery(*musteri);
    ui->gonderen->setModel(musteriModel);
    ui->alan->setModel(musteriModel);
}

void MainWindow::hesapListele(int IBAN)
{
    hesap->prepare("select * from Hesaplar where IBAN = ?");
    hesap->addBindValue(IBAN);
    hesap->exec();
    hesapModel->setQuery(*hesap);
    ui->hesaplar->setModel(hesapModel);
}


void MainWindow::on_pushButton_clicked()
{
    islem->prepare("update Hesaplar set Miktar = ? where IBAN = ?");
    if (gonderenMiktar < ui->miktar->text().toInt()) {
        QMessageBox::critical(this, "İşlem Başarısız", "Yeterli bakiyeniz yok!");
        return;
    }
    islem->addBindValue(gonderenMiktar - ui->miktar->text().toInt());
    islem->addBindValue(gonderenIban);
    if (!islem->exec()) {
        QMessageBox::critical(this, "Transfer Hatası", islem->lastError().text());
    }
    islem->prepare("update Hesaplar set Miktar = ? where IBAN = ?");
    islem->addBindValue(aliciMiktar + ui->miktar->text().toInt());
    islem->addBindValue(aliciIban);
    if (!islem->exec()) {
        QMessageBox::critical(this, "Transfer Hatası", islem->lastError().text());
    }
    hesapListele(gonderenIban);
}

void MainWindow::on_gonderen_clicked(const QModelIndex &index)
{
    gonderenIban = musteriModel->index(index.row(), 0).data().toInt();
    hesapListele(gonderenIban);
    gonderenMiktar = hesapModel->index(0, 1).data().toInt();
    ui->label_6->setText(QString::number(gonderenMiktar));
}

void MainWindow::on_alan_clicked(const QModelIndex &index)
{
    aliciIban = musteriModel->index(index.row(), 0).data().toInt();
    hesapListele(aliciIban);
    aliciMiktar = hesapModel->index(0, 1).data().toInt();
    ui->label_7->setText(QString::number(aliciMiktar));
}
