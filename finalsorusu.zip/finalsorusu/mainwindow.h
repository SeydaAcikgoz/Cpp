#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSqlQuery>
#include <QSqlQueryModel>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void musteriListele();
    void hesapListele(int IBAN);

private slots:
    void on_pushButton_clicked();

    void on_gonderen_clicked(const QModelIndex &index);

    void on_alan_clicked(const QModelIndex &index);

private:
    Ui::MainWindow *ui;
    QSqlQuery *musteri;
    QSqlQueryModel* musteriModel;
    QSqlQuery *hesap;
    QSqlQueryModel *hesapModel;
    QSqlDatabase db;
    QSqlQuery *islem;
    int gonderenIban;
    int aliciIban;
    int gonderenMiktar;
    int aliciMiktar;
};
#endif // MAINWINDOW_H
